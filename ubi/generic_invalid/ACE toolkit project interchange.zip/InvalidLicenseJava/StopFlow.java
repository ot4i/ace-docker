import java.util.ListResourceBundle;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbUserException;
import com.ibm.broker.plugin.MbService;
import com.ibm.broker.javacompute.MbJavaComputeNode;

public class StopFlow extends MbJavaComputeNode
{
    public void onStart() throws MbException {
        MbService.logError("Test_JavaCompute", "onStart()", JavaComputeNodeMessages.MESSAGE_SOURCE, "INVALID NODES", (String)null, (Object[])null);
        throw new MbUserException((Object)this, "onStart()", "", "", "", (Object[])null);
    }
    
    public void evaluate(final MbMessageAssembly arg0) throws MbException {
    }
    
    public static class JavaComputeNodeMessages extends ListResourceBundle
    {
        public static final String MESSAGE_SOURCE;
        public static final String LOGGER_LEVEL = "INVALID NODES";
        private Object[][] messages;
        
        static {
            MESSAGE_SOURCE = JavaComputeNodeMessages.class.getName();
        }
        
        public JavaComputeNodeMessages() {
            this.messages = new Object[][] { { "INVALID NODES", "This flow cannot be started because it uses nodes which are not available under the current license." } };
        }
        
        public Object[][] getContents() {
            return this.messages;
        }
    }
}